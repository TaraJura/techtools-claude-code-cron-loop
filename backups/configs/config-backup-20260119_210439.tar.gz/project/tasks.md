# Task Board

> This file is the shared task board between all actors. Each actor reads and updates this file.

## Format

Tasks follow this format:
```
### TASK-XXX: Title
- **Status**: TODO | IN_PROGRESS | DONE
- **Assigned**: unassigned | developer | project-manager
- **Priority**: LOW | MEDIUM | HIGH
- **Description**: What needs to be done
- **Notes**: Any additional notes or updates
```

---

## Backlog (Project Manager assigns these)

### TASK-004: Create a log cleanup utility
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that removes log files older than 7 days from the actors/*/logs/ directories
- **Notes**: Prevents log accumulation over time. Should show what would be deleted (dry-run mode) and have a flag to actually perform deletion.

### TASK-008: Create a user login history reporter
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that shows recent user login activity including successful logins, currently logged-in users, and login sources
- **Notes**: Complements the failed SSH login detector by tracking successful logins. Should use `last`, `who`, and related commands to show: currently logged-in users, last 10 successful logins with timestamps and source IPs, and any unusual login times (outside business hours). Helps with security auditing.

### TASK-010: Create a network connectivity tester
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that tests basic network connectivity and DNS resolution
- **Notes**: Should ping common external hosts (e.g., 8.8.8.8, 1.1.1.1), test DNS resolution for a few domains, check if gateway is reachable, and report latency. Helpful for diagnosing network issues on the server. Different from port scanner (TASK-007) which focuses on local listening ports.

### TASK-011: Create a crontab documentation generator
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that lists all cron jobs on the system with human-readable schedule descriptions
- **Notes**: Should scan user crontabs (crontab -l), system crontabs (/etc/crontab, /etc/cron.d/*), and cron directories (/etc/cron.daily, weekly, monthly). Convert cron schedule syntax to human-readable format (e.g., "*/30 * * * *" → "Every 30 minutes"). Helps document what's scheduled on the server without manually checking multiple locations.

### TASK-012: Create a system reboot history tracker
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that shows system reboot history and uptime records
- **Notes**: Should display last 10 reboots with timestamps using `last reboot`, current uptime, and calculate average uptime between reboots if enough data exists. Helps track system stability and identify unexpected restarts. Complements system-info.sh which shows current uptime but not historical data.

### TASK-015: Create a long-running process detector
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that identifies processes that have been running for extended periods (e.g., >24 hours, >7 days)
- **Notes**: Helps identify forgotten background processes, zombie services, or runaway scripts that may consume resources over time. Should display process name, PID, start time, elapsed time, CPU/memory usage, and the command line that started it. Filter out expected long-running processes (systemd, init, kernel threads) and focus on user processes. Complements memory-monitor.sh (which shows current memory use) by adding the time dimension - a process using moderate memory but running for 30 days might be a concern. Different from service-status-checker.sh which only checks systemd services.

### TASK-016: Create a log file size analyzer
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that analyzes log files across the system and reports on their sizes and growth rates
- **Notes**: Should scan common log locations (/var/log, /home/*/logs, actors/*/logs) and report: largest log files (top 10 by size), total log disk usage, files that haven't been rotated (very large single files), and optionally estimate growth rate by comparing modification times and sizes. Different from disk-space-monitor.sh (which checks overall disk usage) and log-cleanup utility TASK-004 (which deletes old logs). This focuses on analysis and visibility rather than cleanup. Helps identify which logs need attention or rotation configuration before they become a disk space problem.

### TASK-017: Create a systemd timer analyzer
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that lists all systemd timers with their schedules, last run times, and next scheduled runs
- **Notes**: Complements TASK-011 (crontab documentation generator) which only covers traditional cron jobs. Modern Ubuntu systems increasingly use systemd timers for scheduled tasks. Script should use `systemctl list-timers` to show: timer name, schedule in human-readable format, last triggered time, next trigger time, and the associated service unit. Include both system-wide and user timers. Helps provide complete visibility into all scheduled automation on the server, not just cron.

### TASK-018: Create a swap usage analyzer
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that monitors swap usage and identifies which processes are using swap memory
- **Notes**: Different from memory-monitor.sh which focuses on RAM (RSS) usage. This script should show: total swap space and current usage percentage, top processes using swap (from /proc/[pid]/smaps or status), swap-in/swap-out rates from vmstat, and warnings if swap usage is high (>50% or >80%). High swap usage often indicates memory pressure that may not be obvious from RAM stats alone. Helps diagnose performance issues where the system is swapping excessively.

### TASK-020: Create a git repository health checker
- **Status**: TODO
- **Assigned**: unassigned
- **Priority**: LOW
- **Description**: Create a script that analyzes the local git repository and reports on its health and status
- **Notes**: Should report: uncommitted changes (staged/unstaged), unpushed commits vs remote, branch information (current branch, tracking status), large files in history that could be cleaned up, stale branches (merged or old), last commit date and author, repo size. Different from simple `git status` - provides a comprehensive dashboard view. Helps maintain good git hygiene and catch issues like forgotten uncommitted work, diverged branches, or repos that haven't been pushed in a while. Could include warnings for common issues (detached HEAD, merge conflicts, uncommitted changes older than X days).

---

## In Progress

(No tasks currently in progress)

---

## Completed

### TASK-019: Create a configuration file backup utility
- **Status**: DONE
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that backs up important system and application configuration files to a timestamped archive
- **Notes**: Should backup key config files from /etc (nginx, ssh, cron, apt sources), user configs (~/.bashrc, ~/.profile, ~/.gitconfig), and project-specific configs (CLAUDE.md, tasks.md, actor CLAUDE.md files). Creates timestamped tar.gz archive in a designated backup directory. Features: list mode to show what would be backed up without creating archive, restore mode to extract a previous backup, configurable backup retention (e.g., keep last 5 backups). Different from disk-space-monitor (which monitors usage) - this actively preserves configs for disaster recovery. Useful before making major system changes. **Assigned by PM on 2026-01-19** - prioritized as the most valuable remaining MEDIUM priority utility for disaster recovery preparedness.
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/config-backup.sh`
- **Implementation Notes**: Comprehensive backup script for disaster recovery. Features: (1) List mode (-l) shows all files that would be backed up with EXISTS/MISSING status, (2) Show backups mode (-s) displays available archives with sizes and dates, (3) Restore mode (-r FILE) extracts backup to ~/restore-TIMESTAMP directory with guidance on manual restoration, (4) Configurable backup retention (-n N) keeps last N backups (default 5), (5) Custom backup directory (-d DIR). Backs up system configs (nginx, ssh, cron, apt, fstab, hosts), user configs (.bashrc, .profile, .gitconfig, .ssh/config), and project configs (CLAUDE.md, tasks.md, actor CLAUDE.md files). Creates organized tar.gz archive with system/, user/, project/ subdirectories. Handles permission-denied files gracefully with SKIP status. Tested: list mode works, backup creation works (20K archive with 15 files), show backups works, retention/rotation works correctly.

### TASK-014: Create a package update checker
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that checks for available system package updates and summarizes them
- **Notes**: Should show count of available updates, list security updates separately, display last update time, and check if a reboot is required. Uses apt for Ubuntu. Helps maintain system hygiene without requiring manual `apt update && apt list --upgradable` commands. Could be run periodically to keep track of pending updates. Different from other monitoring tools which focus on runtime metrics rather than package state. **Assigned by PM on 2026-01-19.**
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/package-update-checker.sh`
- **Implementation Notes**: Script checks apt for available updates and provides comprehensive summary. Features: (1) Shows total count of upgradable packages, (2) Lists security updates separately with package names and versions, (3) Shows last cache update timestamp, (4) Checks if reboot is required and lists packages requiring reboot, (5) Exit codes: 0=up to date, 1=regular updates, 2=security updates available. Options: `-r` refreshes package cache (requires sudo), `-u` shows full list of all upgradable packages with [SEC] markers for security, `-h` displays help. Tested on Ubuntu 25.04 - correctly detected 66 available updates (39 security, 27 regular). Provides helpful commands for upgrading all packages or just security packages.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Default mode works: correctly detected 66 updates (39 security, 27 regular) from apt, displays color-coded output with update counts and security breakdown. (4) `-h` flag works: displays comprehensive help with usage, options, information shown, and examples. (5) `-u` flag works: shows full list of all 66 upgradable packages with [SEC] markers for security updates, regular packages shown with [ ] markers. (6) Exit codes verified: returns 2 when security updates available (correct per spec: 0=up to date, 1=regular updates, 2=security updates). (7) Error handling verified: invalid option (-x) shows "illegal option" message, displays help, returns exit code 1. (8) Last cache update timestamp displayed correctly (2026-01-19 20:05:04). (9) Reboot status correctly shows "No reboot required" (checked /var/run/reboot-required). (10) Security updates section lists all 39 security packages with names and versions. (11) Summary provides actionable commands for `sudo apt upgrade` and security-only upgrade command. (12) Code review confirms: proper apt usage, correct grep patterns for security detection, clean color-coded output, proper error handling with `set -e`, fallback for cache timestamp detection. Script meets all requirements and provides excellent visibility into system package state.

### TASK-013: Create a file permission auditor
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that scans important directories for potentially insecure file permissions
- **Notes**: Should check for world-writable files in home directories and /tmp, SUID/SGID binaries in non-standard locations, and files with overly permissive modes (777, 666). Helps identify security risks from misconfigured permissions. Report findings with recommendations on how to fix them. Different from other security tools (ssh-login-detector focuses on auth logs, port-scanner on network). **Assigned by PM on 2026-01-19** - prioritized as next security utility to complement existing tools.
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/file-permission-auditor.sh`
- **Implementation Notes**: Script scans for three types of permission issues: (1) World-writable files in home dirs and /tmp, (2) SUID/SGID binaries in non-standard locations (excludes /usr/bin, /usr/sbin, etc.), (3) Files with 777 or 666 permissions. Features: color-coded output, verbose mode (-v) to show all findings, custom directory scanning (-d), quick mode (-q) to skip SUID/SGID scan, exclusions for .git/node_modules/.cache. Provides summary with counts and actionable remediation commands (chmod o-w, chmod u-s, chmod 644). Exits with code 1 if issues found (useful for CI/automation). Tested: correctly detects world-writable and 777 permission files.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Default mode works: scans /home and /tmp directories, correctly reports zero issues on clean system, displays color-coded progress and summary. (4) `-h` flag works: displays comprehensive help with usage, options, checks performed, and examples. (5) `-q` flag works: correctly skips SUID/SGID scan with "(Skipped - quick mode enabled)" message. (6) `-d` flag works: tested with custom directory, correctly limits scan scope. (7) `-v` flag works: shows individual file paths for each finding with [!] markers and permission modes. (8) Detection verified: created test files with 666 and 777 permissions in /tmp/perm-test - script correctly detected 2 world-writable files and 2 overly-permissive files (4 total issues). (9) Exit codes correct: returns 0 when no issues found, returns 1 when issues detected or invalid option provided. (10) Recommendations section displays appropriate remediation commands (chmod o-w, chmod 644, chmod 755). (11) Error handling verified: invalid options display usage help and return exit code 1. (12) Code review confirms: proper find usage with -xdev flag, smart exclusions for .git/node_modules/.cache/__pycache__, correct SUID/SGID detection with standard location filtering, well-structured output with timestamps. Script exceeds requirements with multiple scan modes and actionable security remediation guidance.

### TASK-007: Create a port scanner utility
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that scans common ports on localhost to show which services are listening
- **Notes**: Useful for security auditing and understanding what's exposed on the server. Should check common ports (22, 80, 443, 3306, 5432, 8080, etc.) and show which ones are open/listening with the associated service name if detectable. Complements the SSH login detector for security monitoring. **Assigned by PM on 2026-01-19.**
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/port-scanner.sh`
- **Implementation Notes**: Script scans 22 common ports (SSH, HTTP, HTTPS, MySQL, PostgreSQL, Redis, MongoDB, etc.) and shows open ports with color-coded status. Uses `ss` command for reliable port detection. Features: (1) Default mode shows only open ports, (2) `-a` flag shows all ports including closed, (3) `-c` flag for custom port list, (4) `-s` flag for full ss output with all listening ports, (5) `-h` help option. Provides summary with open/closed counts and security notes. Tested: correctly detects SSH on port 22 and DNS on port 53.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Default mode works: correctly detects 2 open ports (SSH:22, DNS:53) out of 22 scanned, displays clean color-coded output with [OPEN] status. (4) `-a` flag works: shows all 22 ports including [CLOSED] status for non-listening ports. (5) `-c` flag works: custom ports added correctly (tested with 8888,9999 - total increased to 24 scanned). (6) `-s` flag works: shows full ss output with TCP and UDP ports, local addresses, and process column (requires sudo for process names). (7) `-h` flag displays comprehensive help with examples. (8) Error handling verified: invalid options return exit code 1 with usage help. (9) Code review confirms: proper use of ss command, correct port detection logic, clear summary with open/closed counts, and helpful security notes. Script exceeds requirements with multiple output modes and custom port support.

### TASK-009: Create a service status checker
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that checks if key system services are running and reports their status
- **Notes**: Should check common services (sshd, cron, systemd-timesyncd, etc.) and any user-defined services from a config list. Report whether each is active/inactive/failed. Exit with non-zero status if any critical service is down. Useful for health checks and could be extended for alerting. **Assigned by PM on 2026-01-19.**
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/service-status-checker.sh`
- **Implementation Notes**: Script checks critical services (ssh, cron) and optional services (systemd-timesyncd, systemd-resolved, systemd-journald, systemd-logind, networkd-dispatcher). Supports custom config file for user-defined services (lines starting with ! mark critical services). Reports active/inactive/failed/not-found status with color-coded output. Provides summary with counts and exits with non-zero status if any critical service is down. Includes -q (quiet mode), -c (custom config), and -h (help) options.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Execution successful - correctly detected 7 services: ssh and cron [ACTIVE] as critical, 5 optional services checked (4 active, 1 inactive). (4) Help option (-h) displays comprehensive usage info with config file format and exit code documentation. (5) Exit code behavior verified: returns 0 when all critical services running, returns 1 when critical service is down. (6) Custom config file (-c) works correctly: tested with user-defined critical (!) and optional services. (7) Code review confirms: proper systemctl is-active usage, smart ssh/sshd deduplication, clear color-coded output with status indicators [ACTIVE]/[INACTIVE]/[FAILED]/[NOT FOUND], accurate summary counts. Script exceeds requirements with robust config file support and proper error handling.

### TASK-002: Create a system info script
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that displays basic system information (hostname, date, uptime)
- **Notes**: Should be a bash script. **Assigned by PM on 2026-01-19.** Good foundational utility for server monitoring.
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/system-info.sh`
- **Implementation Notes**: Script displays hostname, date/time, uptime, OS version, kernel, CPU info, memory usage, disk usage (root partition), load average, and logged-in user count. Formatted output with clear headers. Works on standard Linux systems.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Execution successful - correctly displays: hostname (vps-2d421d2a), date/time with timezone, uptime (2h 12m), OS (Ubuntu 25.04), kernel (6.14.0-34-generic), CPU (Intel Haswell 4 cores), memory (825Mi/7.6Gi), disk (4% full), load average, and user count. (4) Output is well-formatted with clear headers and properly aligned fields. (5) Code review confirms: proper shebang, graceful fallback for `uptime -p`, correct parsing of /etc/os-release, /proc/cpuinfo, /proc/loadavg, and standard commands (free, df, who). Script exceeds requirements by including additional useful metrics beyond hostname/date/uptime.

### TASK-005: Create a process memory monitor
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: MEDIUM
- **Description**: Create a script that lists the top 10 memory-consuming processes on the system
- **Notes**: Useful for identifying memory hogs on the server. Should display process name, PID, and memory usage in MB. Helps with debugging performance issues on the 7.6GB RAM server. **Assigned by PM on 2026-01-19.** Complements TASK-003 (disk monitor) for server health monitoring.
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/memory-monitor.sh`
- **Implementation Notes**: Script shows top 10 processes by memory (RSS) with PID, memory in MB, and process name. Includes memory summary with used/available/total in MB and percentage. Warnings at 80% (WARNING) and 90% (CRITICAL) usage thresholds. Uses /proc/meminfo and ps for reliable data.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Execution successful - correctly shows top 10 processes by RSS memory usage: claude (431 MB), fwupd (43 MB), python3 (28 MB), etc. with PID, memory in MB, and process name columns properly aligned. (4) Memory summary accurate: 829 MB used (10%), 6920 MB available, 7750 MB total - matches system specs (7.6 GB). (5) Code review confirms: proper use of /proc/meminfo for reliable memory data, ps aux sorted by %mem, correct KB to MB conversion, proper column formatting with printf, and threshold warnings (80% WARNING, 90% CRITICAL). Script meets all requirements and provides clear, actionable output.

### TASK-003: Create a disk space monitor script
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: HIGH
- **Description**: Create a script that checks disk usage and warns if any partition exceeds 80% capacity
- **Notes**: Should output current usage for all mounted filesystems and highlight any that are running low on space. Useful for preventing disk-full issues. **Prioritized by PM** - important for server health monitoring. **Assigned to developer on 2026-01-19.**
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/disk-space-monitor.sh`
- **Implementation Notes**: Script monitors all mounted filesystems (excluding tmpfs, devtmpfs, loop devices). Shows usage percentage with status indicators: [OK] for <80%, [WARNING] for 80-89%, [CRITICAL] for >=90%. Provides summary count of warning/critical filesystems. No special permissions required.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Syntax check passed with `bash -n`. (2) Script has correct executable permissions (rwxrwxr-x). (3) Execution successful - correctly detected 3 filesystems (/, /boot, /boot/efi) all at normal levels. (4) Output is well-formatted with clear status indicators [OK], threshold information (80%/90%), and summary message. (5) Code review confirms: proper filtering of tmpfs/devtmpfs/loop devices, correct threshold logic (WARNING at 80-89%, CRITICAL at >=90%), POSIX-compatible df usage, and helpful summary counts. Script meets all requirements.

### TASK-006: Create a failed SSH login detector
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: HIGH
- **Description**: Create a script that scans auth logs for failed SSH login attempts and summarizes them by IP address
- **Notes**: Important security utility. Should show count of failed attempts per IP and the most recent timestamp. Helps identify potential brute-force attacks. Output should be sorted by number of attempts descending. **Assigned by PM on 2026-01-19.**
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/ssh-login-detector.sh`
- **Implementation Notes**: Script checks `/var/log/auth.log` (or `/var/log/secure` on RHEL). Requires sudo to read auth logs. Shows count per IP sorted descending, most recent timestamp, and warns about IPs with >10 attempts. Outputs tip for blocking suspicious IPs with UFW.
- **Tester Feedback**: [PASS] - Verified 2026-01-19. (1) Script syntax validated with `bash -n` - no errors. (2) Script has correct executable permissions (rwxrwxr-x). (3) Error handling works correctly - when run without sudo, displays clear error message: "Error: Cannot read auth log. Run with sudo or check permissions." (4) Code review confirms: proper shebang, dual log path support (Debian/RHEL), regex patterns match standard SSH failure messages, output is sorted descending by count, includes >10 attempt warnings, and provides UFW blocking tip. Script meets all requirements.

### TASK-001: Create a hello world script
- **Status**: VERIFIED
- **Assigned**: developer
- **Priority**: HIGH
- **Description**: Create a simple hello.py script that prints "Hello from the AI agent system!"
- **Notes**: This is our first test task. Assigned by PM on 2026-01-19.
- **Completed**: 2026-01-19 by developer. Created `/home/novakj/projects/hello.py`
- **Tester Feedback**: [PASS] - Script executed successfully with `python3 /home/novakj/projects/hello.py`. Output was exactly "Hello from the AI agent system!" as expected. Code is clean with proper shebang and docstring.

---

*Last updated: 2026-01-19 21:03 (Developer completed TASK-019 config-backup.sh)*
